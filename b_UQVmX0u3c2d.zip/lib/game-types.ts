export type TileType = 
  | 'start'
  | 'virus_infection'
  | 'immune_response'
  | 'medication'
  | 'virus_mutation'
  | 'antibody'
  | 'bloodstream'
  | 'organ'
  | 'question'
  | 'normal';

export type PlayerType = 'immune_cell' | 'virus';

export interface Tile {
  id: number;
  type: TileType;
  x: number;
  y: number;
  label: string;
  description: string;
}

export interface Player {
  id: number;
  name: string;
  type: PlayerType;
  position: number;
  health: number;
  power: number;
  color: string;
}

export interface Question {
  id: number;
  question: string;
  correctAnswer: string;
  keywords: string[];
  difficulty: 'easy' | 'medium' | 'hard';
  explanation: string;
}

export interface GameState {
  players: Player[];
  currentPlayerIndex: number;
  diceValue: number | null;
  isRolling: boolean;
  gamePhase: 'setup' | 'waiting' | 'rolling' | 'moving' | 'event' | 'question' | 'finished';
  currentEvent: string | null;
  currentQuestion: Question | null;
  winner: Player | null;
  usedQuestions: number[];
}

export const PLAYER_COLORS = [
  '#38bdf8', // sky
  '#4ade80', // green
  '#f472b6', // pink
  '#fbbf24', // amber
  '#a78bfa', // violet
];

export const PLAYER_ICONS = [
  'Leucócito',
  'Macrófago',
  'Linfócito T',
  'Linfócito B',
  'Célula NK',
];

export const TILE_CONFIGS: Record<TileType, { emoji: string; color: string; effect: string }> = {
  start: { emoji: '🏁', color: 'from-emerald-500 to-teal-600', effect: 'Início da jornada!' },
  virus_infection: { emoji: '🦠', color: 'from-red-500 to-rose-600', effect: 'Infecção viral! Perde 10 de saúde.' },
  immune_response: { emoji: '🛡️', color: 'from-blue-500 to-cyan-600', effect: 'Resposta imune! Ganha 15 de poder.' },
  medication: { emoji: '💊', color: 'from-teal-500 to-emerald-600', effect: 'Medicamento! Recupera 20 de saúde.' },
  virus_mutation: { emoji: '🧬', color: 'from-purple-500 to-violet-600', effect: 'Mutação! Efeito aleatório.' },
  antibody: { emoji: '🔬', color: 'from-cyan-500 to-blue-600', effect: 'Anticorpos! Ganha 10 de poder e saúde.' },
  bloodstream: { emoji: '❤️', color: 'from-red-600 to-rose-700', effect: 'Corrente sanguínea! Avança 2 casas.' },
  organ: { emoji: '🫀', color: 'from-pink-500 to-rose-500', effect: 'Órgão vital! Descanse uma rodada.' },
  question: { emoji: '❓', color: 'from-amber-500 to-orange-600', effect: 'Carta de Pergunta! Responda corretamente para ganhar bônus.' },
  normal: { emoji: '⚪', color: 'from-slate-400 to-slate-500', effect: 'Casa neutra.' },
};

export const IMMUNOLOGY_QUESTIONS: Question[] = [
  {
    id: 1,
    question: 'Qual célula do sistema imunológico é responsável por produzir anticorpos?',
    correctAnswer: 'Linfócito B',
    keywords: ['linfócito b', 'linfocito b', 'célula b', 'celula b', 'plasmócito', 'plasmocito'],
    difficulty: 'easy',
    explanation: 'Os Linfócitos B (ou células B) são responsáveis pela produção de anticorpos, proteínas que reconhecem e neutralizam patógenos.',
  },
  {
    id: 2,
    question: 'O que significa a sigla MHC no contexto da imunologia?',
    correctAnswer: 'Complexo Principal de Histocompatibilidade',
    keywords: ['complexo', 'histocompatibilidade', 'major histocompatibility complex', 'apresentação', 'antígeno'],
    difficulty: 'hard',
    explanation: 'MHC (Major Histocompatibility Complex) são proteínas de superfície celular essenciais para a apresentação de antígenos.',
  },
  {
    id: 3,
    question: 'Qual é a função principal dos macrófagos?',
    correctAnswer: 'Fagocitose de patógenos e células mortas',
    keywords: ['fagocitose', 'fagocitar', 'engolir', 'destruir', 'patógenos', 'patogenos', 'células mortas', 'celulas mortas'],
    difficulty: 'easy',
    explanation: 'Os macrófagos são células especializadas em fagocitose, engolfando e digerindo patógenos, células mortas e detritos celulares.',
  },
  {
    id: 4,
    question: 'O que são citocinas?',
    correctAnswer: 'Proteínas de sinalização celular do sistema imunológico',
    keywords: ['proteína', 'proteina', 'sinalização', 'sinalizacao', 'comunicação', 'comunicacao', 'mensageiro', 'interleucina'],
    difficulty: 'medium',
    explanation: 'Citocinas são proteínas pequenas importantes na sinalização celular, regulando a resposta imune e inflamação.',
  },
  {
    id: 5,
    question: 'Qual órgão é considerado o principal órgão linfático secundário?',
    correctAnswer: 'Baço',
    keywords: ['baço', 'baco', 'spleen'],
    difficulty: 'medium',
    explanation: 'O baço é o maior órgão linfático secundário, filtrando o sangue e armazenando células imunológicas.',
  },
  {
    id: 6,
    question: 'O que é a resposta imune humoral?',
    correctAnswer: 'Resposta mediada por anticorpos',
    keywords: ['anticorpos', 'anticorpo', 'imunoglobulina', 'linfócito b', 'linfocito b'],
    difficulty: 'medium',
    explanation: 'A resposta imune humoral é mediada por anticorpos produzidos pelos linfócitos B, atuando contra patógenos extracelulares.',
  },
  {
    id: 7,
    question: 'Qual célula é responsável por destruir células infectadas por vírus?',
    correctAnswer: 'Linfócito T citotóxico (CD8+)',
    keywords: ['linfócito t', 'linfocito t', 'cd8', 'citotóxico', 'citotoxico', 'killer', 'célula t', 'celula t'],
    difficulty: 'medium',
    explanation: 'Os Linfócitos T citotóxicos (CD8+) reconhecem e destroem células infectadas por vírus ou células tumorais.',
  },
  {
    id: 8,
    question: 'O que é a memória imunológica?',
    correctAnswer: 'Capacidade do sistema imune de lembrar patógenos anteriores',
    keywords: ['lembrar', 'memória', 'memoria', 'células de memória', 'celulas de memoria', 'reinfecção', 'reinfeccao', 'vacina'],
    difficulty: 'easy',
    explanation: 'A memória imunológica permite uma resposta mais rápida e eficaz em encontros subsequentes com o mesmo patógeno.',
  },
  {
    id: 9,
    question: 'Qual é a função das células dendríticas?',
    correctAnswer: 'Apresentação de antígenos aos linfócitos T',
    keywords: ['apresentação', 'apresentacao', 'antígeno', 'antigeno', 'ativar', 'linfócito t', 'linfocito t'],
    difficulty: 'hard',
    explanation: 'As células dendríticas são as principais células apresentadoras de antígenos, iniciando respostas imunes adaptativas.',
  },
  {
    id: 10,
    question: 'O que é um antígeno?',
    correctAnswer: 'Substância que desencadeia uma resposta imune',
    keywords: ['substância', 'substancia', 'molécula', 'molecula', 'resposta imune', 'reconhecido', 'estranho'],
    difficulty: 'easy',
    explanation: 'Antígenos são moléculas reconhecidas pelo sistema imune como estranhas, desencadeando uma resposta imunológica.',
  },
  {
    id: 11,
    question: 'Onde os linfócitos T amadurecem?',
    correctAnswer: 'Timo',
    keywords: ['timo', 'thymus'],
    difficulty: 'easy',
    explanation: 'Os linfócitos T migram da medula óssea para o timo, onde amadurecem e passam por seleção.',
  },
  {
    id: 12,
    question: 'O que é inflamação?',
    correctAnswer: 'Resposta protetora do corpo a lesões ou infecções',
    keywords: ['resposta', 'proteção', 'protecao', 'lesão', 'lesao', 'infecção', 'infeccao', 'vermelhidão', 'inchaço'],
    difficulty: 'easy',
    explanation: 'A inflamação é uma resposta protetora caracterizada por calor, vermelhidão, inchaço e dor, auxiliando na cura.',
  },
  {
    id: 13,
    question: 'Qual é a diferença entre imunidade inata e adaptativa?',
    correctAnswer: 'Inata é inespecífica e rápida; adaptativa é específica e tem memória',
    keywords: ['inespecífica', 'inespecifica', 'específica', 'especifica', 'rápida', 'rapida', 'memória', 'memoria', 'nascença', 'nascenca'],
    difficulty: 'medium',
    explanation: 'A imunidade inata é a primeira linha de defesa, não específica. A adaptativa é específica para cada patógeno e desenvolve memória.',
  },
  {
    id: 14,
    question: 'O que são neutrófilos?',
    correctAnswer: 'Células brancas mais abundantes que combatem infecções bacterianas',
    keywords: ['célula', 'celula', 'branca', 'leucócito', 'leucocito', 'bactéria', 'bacteria', 'fagocitose', 'abundante'],
    difficulty: 'medium',
    explanation: 'Neutrófilos são os leucócitos mais abundantes, sendo primeiros a chegar em locais de infecção bacteriana.',
  },
  {
    id: 15,
    question: 'O que é alergia?',
    correctAnswer: 'Reação exagerada do sistema imune a substâncias inofensivas',
    keywords: ['reação', 'reacao', 'exagerada', 'hipersensibilidade', 'inofensiva', 'histamina', 'ige'],
    difficulty: 'easy',
    explanation: 'Alergias são respostas imunes exageradas a substâncias normalmente inofensivas, como pólen ou alimentos.',
  },
];

export function generateBoardTiles(): Tile[] {
  const tiles: Tile[] = [];
  const boardPath = [
    // Outer ring - clockwise starting from top-left
    { x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 3, y: 0 }, { x: 4, y: 0 }, { x: 5, y: 0 }, { x: 6, y: 0 },
    { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 3 }, { x: 6, y: 4 }, { x: 6, y: 5 }, { x: 6, y: 6 },
    { x: 5, y: 6 }, { x: 4, y: 6 }, { x: 3, y: 6 }, { x: 2, y: 6 }, { x: 1, y: 6 }, { x: 0, y: 6 },
    { x: 0, y: 5 }, { x: 0, y: 4 }, { x: 0, y: 3 }, { x: 0, y: 2 }, { x: 0, y: 1 },
    // Inner ring
    { x: 2, y: 2 }, { x: 3, y: 2 }, { x: 4, y: 2 },
    { x: 4, y: 3 }, { x: 4, y: 4 },
    { x: 3, y: 4 }, { x: 2, y: 4 },
    { x: 2, y: 3 },
    // Center
    { x: 3, y: 3 },
  ];

  const tileTypes: TileType[] = [
    'start', 'bloodstream', 'question', 'normal', 'immune_response', 'medication', 'question',
    'antibody', 'virus_mutation', 'question', 'bloodstream', 'organ', 'virus_infection',
    'question', 'normal', 'medication', 'question', 'virus_mutation', 'antibody',
    'question', 'bloodstream', 'virus_infection', 'organ', 'question',
    'medication', 'question', 'antibody',
    'question', 'organ',
    'bloodstream', 'virus_infection',
    'question',
    'normal',
  ];

  const labels: Record<TileType, string[]> = {
    start: ['Início'],
    virus_infection: ['Infecção', 'Contágio', 'Invasão'],
    immune_response: ['Defesa', 'Imunidade', 'Proteção'],
    medication: ['Remédio', 'Tratamento', 'Cura'],
    virus_mutation: ['Mutação', 'Evolução', 'Adaptação'],
    antibody: ['Anticorpo', 'Proteína', 'Defensor'],
    bloodstream: ['Sangue', 'Circulação', 'Fluxo'],
    organ: ['Órgão', 'Tecido', 'Sistema'],
    question: ['Pergunta', 'Quiz', 'Desafio'],
    normal: ['Passagem', 'Caminho', 'Trilha'],
  };

  boardPath.forEach((pos, index) => {
    const type = tileTypes[index] || 'normal';
    const typeLabels = labels[type];
    const label = typeLabels[index % typeLabels.length];
    
    tiles.push({
      id: index,
      type,
      x: pos.x,
      y: pos.y,
      label,
      description: TILE_CONFIGS[type].effect,
    });
  });

  return tiles;
}

export function createPlayer(id: number, name: string, colorIndex: number): Player {
  return {
    id,
    name,
    type: 'immune_cell',
    position: 0,
    health: 100,
    power: 50,
    color: PLAYER_COLORS[colorIndex % PLAYER_COLORS.length],
  };
}

export function evaluateAnswer(userAnswer: string, question: Question): { correct: boolean; score: number } {
  const normalizedAnswer = userAnswer.toLowerCase().trim();
  const normalizedCorrect = question.correctAnswer.toLowerCase();
  
  // Exact match
  if (normalizedAnswer === normalizedCorrect) {
    return { correct: true, score: 100 };
  }
  
  // Check keywords
  let matchedKeywords = 0;
  for (const keyword of question.keywords) {
    if (normalizedAnswer.includes(keyword.toLowerCase())) {
      matchedKeywords++;
    }
  }
  
  const keywordScore = (matchedKeywords / question.keywords.length) * 100;
  
  // Consider partially correct if at least 40% of keywords match
  if (keywordScore >= 40) {
    return { correct: true, score: Math.round(keywordScore) };
  }
  
  return { correct: false, score: 0 };
}

export function getRandomQuestion(usedQuestions: number[]): Question | null {
  const availableQuestions = IMMUNOLOGY_QUESTIONS.filter(q => !usedQuestions.includes(q.id));
  if (availableQuestions.length === 0) {
    // Reset if all questions used
    return IMMUNOLOGY_QUESTIONS[Math.floor(Math.random() * IMMUNOLOGY_QUESTIONS.length)];
  }
  return availableQuestions[Math.floor(Math.random() * availableQuestions.length)];
}
