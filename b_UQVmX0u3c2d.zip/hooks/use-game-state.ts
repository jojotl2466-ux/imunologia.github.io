'use client';

import { useState, useCallback } from 'react';
import type { GameState, Tile, Player, Question } from '@/lib/game-types';
import { generateBoardTiles, createPlayer, TILE_CONFIGS, getRandomQuestion } from '@/lib/game-types';

interface PlayerSetup {
  name: string;
  icon: string;
}

export function useGameState() {
  const [tiles] = useState<Tile[]>(generateBoardTiles);
  const [gameState, setGameState] = useState<GameState>({
    players: [],
    currentPlayerIndex: 0,
    diceValue: null,
    isRolling: false,
    gamePhase: 'setup',
    currentEvent: null,
    currentQuestion: null,
    winner: null,
    usedQuestions: [],
  });

  const initializePlayers = useCallback((playerSetups: PlayerSetup[]) => {
    const players = playerSetups.map((setup, index) => 
      createPlayer(index + 1, setup.name, index)
    );
    
    setGameState(prev => ({
      ...prev,
      players,
      currentPlayerIndex: 0,
      gamePhase: 'waiting',
    }));
  }, []);

  const rollDice = useCallback(() => {
    if (gameState.isRolling || gameState.gamePhase === 'moving') return;

    setGameState(prev => ({ ...prev, isRolling: true, gamePhase: 'rolling' }));

    // Simulate dice roll animation
    let rollCount = 0;
    const maxRolls = 10;
    const interval = setInterval(() => {
      const randomValue = Math.floor(Math.random() * 6) + 1;
      setGameState(prev => ({ ...prev, diceValue: randomValue }));
      rollCount++;

      if (rollCount >= maxRolls) {
        clearInterval(interval);
        const finalValue = Math.floor(Math.random() * 6) + 1;
        setGameState(prev => ({ 
          ...prev, 
          diceValue: finalValue, 
          isRolling: false,
          gamePhase: 'moving',
        }));

        // Auto-move after a short delay
        setTimeout(() => {
          movePlayer(finalValue);
        }, 500);
      }
    }, 80);
  }, [gameState.isRolling, gameState.gamePhase]);

  const movePlayer = useCallback((steps: number) => {
    setGameState(prev => {
      const currentPlayer = prev.players[prev.currentPlayerIndex];
      const newPosition = Math.min(currentPlayer.position + steps, tiles.length - 1);
      const landedTile = tiles[newPosition];

      // Apply tile effects
      let updatedPlayer = { ...currentPlayer, position: newPosition };
      let newQuestion: Question | null = null;
      let newPhase: GameState['gamePhase'] = 'event';
      
      if (landedTile) {
        switch (landedTile.type) {
          case 'virus_infection':
            updatedPlayer.health = Math.max(0, updatedPlayer.health - 10);
            break;
          case 'immune_response':
            updatedPlayer.power = Math.min(100, updatedPlayer.power + 15);
            break;
          case 'medication':
            updatedPlayer.health = Math.min(100, updatedPlayer.health + 20);
            break;
          case 'virus_mutation':
            // Random effect
            if (Math.random() > 0.5) {
              updatedPlayer.health = Math.max(0, updatedPlayer.health - 5);
              updatedPlayer.power = Math.min(100, updatedPlayer.power + 10);
            } else {
              updatedPlayer.health = Math.min(100, updatedPlayer.health + 5);
              updatedPlayer.power = Math.max(0, updatedPlayer.power - 5);
            }
            break;
          case 'antibody':
            updatedPlayer.health = Math.min(100, updatedPlayer.health + 10);
            updatedPlayer.power = Math.min(100, updatedPlayer.power + 10);
            break;
          case 'bloodstream':
            // Move extra 2 spaces
            updatedPlayer.position = Math.min(updatedPlayer.position + 2, tiles.length - 1);
            break;
          case 'question':
            // Get a random question
            newQuestion = getRandomQuestion(prev.usedQuestions);
            newPhase = 'question';
            break;
        }
      }

      const updatedPlayers = prev.players.map((p, i) => 
        i === prev.currentPlayerIndex ? updatedPlayer : p
      );

      // Check for winner
      const winner = updatedPlayer.position >= tiles.length - 1 ? updatedPlayer : null;

      return {
        ...prev,
        players: updatedPlayers,
        gamePhase: newPhase,
        currentEvent: landedTile?.description || null,
        currentQuestion: newQuestion,
        winner,
        usedQuestions: newQuestion ? [...prev.usedQuestions, newQuestion.id] : prev.usedQuestions,
      };
    });
  }, [tiles]);

  const answerQuestion = useCallback((correct: boolean, score: number) => {
    setGameState(prev => {
      const currentPlayer = prev.players[prev.currentPlayerIndex];
      let updatedPlayer = { ...currentPlayer };

      if (correct) {
        // Reward based on score
        const powerBonus = Math.round(15 * (score / 100));
        const healthBonus = Math.round(10 * (score / 100));
        updatedPlayer.power = Math.min(100, updatedPlayer.power + powerBonus);
        updatedPlayer.health = Math.min(100, updatedPlayer.health + healthBonus);
      } else {
        // Penalty for wrong answer
        updatedPlayer.health = Math.max(0, updatedPlayer.health - 5);
      }

      const updatedPlayers = prev.players.map((p, i) => 
        i === prev.currentPlayerIndex ? updatedPlayer : p
      );

      return {
        ...prev,
        players: updatedPlayers,
        gamePhase: 'event',
        currentQuestion: null,
      };
    });
  }, []);

  const endTurn = useCallback(() => {
    setGameState(prev => {
      if (prev.winner) return prev;
      
      return {
        ...prev,
        currentPlayerIndex: (prev.currentPlayerIndex + 1) % prev.players.length,
        gamePhase: 'waiting',
        currentEvent: null,
        currentQuestion: null,
        diceValue: null,
      };
    });
  }, []);

  const resetGame = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      players: prev.players.map(p => ({
        ...p,
        position: 0,
        health: 100,
        power: 50,
      })),
      currentPlayerIndex: 0,
      diceValue: null,
      isRolling: false,
      gamePhase: 'waiting',
      currentEvent: null,
      currentQuestion: null,
      winner: null,
      usedQuestions: [],
    }));
  }, []);

  const goToSetup = useCallback(() => {
    setGameState({
      players: [],
      currentPlayerIndex: 0,
      diceValue: null,
      isRolling: false,
      gamePhase: 'setup',
      currentEvent: null,
      currentQuestion: null,
      winner: null,
      usedQuestions: [],
    });
  }, []);

  const currentPlayer = gameState.players[gameState.currentPlayerIndex];
  const currentTile = currentPlayer ? tiles[currentPlayer.position] : null;

  return {
    tiles,
    gameState,
    currentPlayer,
    currentTile,
    initializePlayers,
    rollDice,
    answerQuestion,
    endTurn,
    resetGame,
    goToSetup,
  };
}
