'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PLAYER_COLORS, PLAYER_ICONS } from '@/lib/game-types';

interface PlayerSetup {
  name: string;
  icon: string;
}

interface GameSetupProps {
  onStartGame: (players: PlayerSetup[]) => void;
}

export function GameSetup({ onStartGame }: GameSetupProps) {
  const [playerCount, setPlayerCount] = useState<number>(2);
  const [players, setPlayers] = useState<PlayerSetup[]>(
    Array(5).fill(null).map((_, i) => ({ name: '', icon: PLAYER_ICONS[i] }))
  );
  const [step, setStep] = useState<'count' | 'names'>('count');

  const handlePlayerCountSelect = (count: number) => {
    setPlayerCount(count);
    setStep('names');
  };

  const handleNameChange = (index: number, name: string) => {
    const newPlayers = [...players];
    newPlayers[index] = { ...newPlayers[index], name };
    setPlayers(newPlayers);
  };

  const handleStartGame = () => {
    const activePlayers = players.slice(0, playerCount).map((p, i) => ({
      name: p.name.trim() || `Jogador ${i + 1}`,
      icon: p.icon,
    }));
    onStartGame(activePlayers);
  };

  const canStart = players.slice(0, playerCount).every(p => p.name.trim().length > 0);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-32 h-32 bg-teal-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-lg"
      >
        {/* Title */}
        <div className="text-center mb-8">
          <motion.h1 
            className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-400 mb-3"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            ImmunoQuest
          </motion.h1>
          <p className="text-slate-400 text-sm md:text-base">
            A batalha pelo sistema imunológico
          </p>
        </div>

        {/* Card */}
        <motion.div
          className="bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-6 md:p-8"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          {step === 'count' ? (
            <div>
              <h2 className="text-xl font-semibold text-slate-200 mb-6 text-center">
                Quantos jogadores?
              </h2>
              <div className="grid grid-cols-5 gap-3">
                {[2, 3, 4, 5].map((count) => (
                  <motion.button
                    key={count}
                    onClick={() => handlePlayerCountSelect(count)}
                    className="aspect-square rounded-xl bg-slate-700/50 border-2 border-slate-600/50 hover:border-teal-500/50 hover:bg-slate-700 transition-all flex items-center justify-center text-2xl font-bold text-slate-300 hover:text-teal-400"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {count}
                  </motion.button>
                ))}
              </div>
              <p className="text-center text-slate-500 text-sm mt-4">
                Selecione de 2 a 5 jogadores
              </p>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-6">
                <button
                  onClick={() => setStep('count')}
                  className="text-slate-400 hover:text-slate-200 text-sm flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  Voltar
                </button>
                <h2 className="text-lg font-semibold text-slate-200">
                  {playerCount} Jogadores
                </h2>
              </div>

              <div className="space-y-4">
                {Array.from({ length: playerCount }).map((_, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    {/* Player color indicator */}
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                      style={{ backgroundColor: PLAYER_COLORS[index] }}
                    >
                      {index + 1}
                    </div>
                    
                    {/* Name input */}
                    <div className="flex-1">
                      <Input
                        type="text"
                        placeholder={`Nome do Jogador ${index + 1}`}
                        value={players[index].name}
                        onChange={(e) => handleNameChange(index, e.target.value)}
                        className="bg-slate-700/50 border-slate-600/50 text-slate-200 placeholder:text-slate-500 focus:border-teal-500/50"
                        maxLength={20}
                      />
                    </div>

                    {/* Cell type indicator */}
                    <div className="text-xs text-slate-500 w-20 text-right shrink-0 hidden sm:block">
                      {PLAYER_ICONS[index]}
                    </div>
                  </motion.div>
                ))}
              </div>

              <Button
                onClick={handleStartGame}
                disabled={!canStart}
                className="w-full mt-6 bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Iniciar Jogo
              </Button>

              {!canStart && (
                <p className="text-center text-amber-500/70 text-xs mt-3">
                  Preencha o nome de todos os jogadores
                </p>
              )}
            </div>
          )}
        </motion.div>

        {/* Game info */}
        <motion.div
          className="mt-6 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            Responda perguntas de imunologia, colete anticorpos e chegue ao final para vencer!
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
