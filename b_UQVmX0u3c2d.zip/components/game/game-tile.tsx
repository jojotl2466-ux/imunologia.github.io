'use client';

import { motion } from 'framer-motion';
import type { Tile, Player } from '@/lib/game-types';
import { TILE_CONFIGS } from '@/lib/game-types';

interface GameTileProps {
  tile: Tile;
  players: Player[];
  isHighlighted: boolean;
  onClick: () => void;
}

export function GameTile({ tile, players, isHighlighted, onClick }: GameTileProps) {
  const config = TILE_CONFIGS[tile.type];
  const playersOnTile = players.filter(p => p.position === tile.id);

  return (
    <motion.div
      onClick={onClick}
      className={`
        relative w-full aspect-square rounded-xl cursor-pointer
        bg-gradient-to-br ${config.color}
        shadow-lg border-2 border-white/20
        flex flex-col items-center justify-center gap-1
        overflow-hidden
        ${isHighlighted ? 'ring-4 ring-yellow-400 ring-opacity-75' : ''}
      `}
      whileHover={{ scale: 1.05, zIndex: 10 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        boxShadow: isHighlighted 
          ? '0 0 20px rgba(250, 204, 21, 0.6)' 
          : '0 4px 6px rgba(0, 0, 0, 0.3)'
      }}
      transition={{ 
        duration: 0.3,
        delay: tile.id * 0.02,
      }}
    >
      {/* Tile background pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.3),transparent_70%)]" />
      </div>

      {/* Tile number */}
      <span className="absolute top-1 left-2 text-[10px] font-bold text-white/70">
        {tile.id + 1}
      </span>

      {/* Emoji icon */}
      <span className="text-2xl drop-shadow-md">{config.emoji}</span>
      
      {/* Tile label */}
      <span className="text-[9px] font-semibold text-white text-center px-1 drop-shadow-sm leading-tight">
        {tile.label}
      </span>

      {/* Players on this tile */}
      {playersOnTile.length > 0 && (
        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
          {playersOnTile.map((player, index) => (
            <motion.div
              key={player.id}
              initial={{ scale: 0, y: -20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-5 h-5 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-[10px] font-bold text-white"
              style={{ 
                backgroundColor: player.color,
                zIndex: playersOnTile.length - index,
              }}
            >
              {player.name[0]}
            </motion.div>
          ))}
        </div>
      )}

      {/* Glow effect for special tiles */}
      {tile.type !== 'normal' && (
        <motion.div
          className="absolute inset-0 rounded-xl"
          animate={{
            boxShadow: [
              'inset 0 0 10px rgba(255,255,255,0.2)',
              'inset 0 0 20px rgba(255,255,255,0.4)',
              'inset 0 0 10px rgba(255,255,255,0.2)',
            ],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      )}
    </motion.div>
  );
}
