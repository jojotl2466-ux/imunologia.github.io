'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { Question } from '@/lib/game-types';
import { evaluateAnswer } from '@/lib/game-types';

interface QuestionModalProps {
  question: Question | null;
  isOpen: boolean;
  playerName: string;
  playerColor: string;
  onAnswer: (correct: boolean, score: number) => void;
}

export function QuestionModal({ question, isOpen, playerName, playerColor, onAnswer }: QuestionModalProps) {
  const [answer, setAnswer] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<{ correct: boolean; score: number } | null>(null);

  const handleSubmit = () => {
    if (!question || !answer.trim()) return;
    
    const evaluation = evaluateAnswer(answer, question);
    setResult(evaluation);
    setSubmitted(true);
  };

  const handleClose = () => {
    if (result) {
      onAnswer(result.correct, result.score);
      setAnswer('');
      setSubmitted(false);
      setResult(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !submitted) {
      handleSubmit();
    }
  };

  if (!question) return null;

  const difficultyColors = {
    easy: 'text-emerald-400 bg-emerald-500/20',
    medium: 'text-amber-400 bg-amber-500/20',
    hard: 'text-red-400 bg-red-500/20',
  };

  const difficultyLabels = {
    easy: 'Fácil',
    medium: 'Média',
    hard: 'Difícil',
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="w-full max-w-lg bg-slate-800 rounded-2xl border border-slate-700/50 overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">❓</span>
                  <span className="font-semibold text-white">Carta de Pergunta</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${difficultyColors[question.difficulty]}`}>
                  {difficultyLabels[question.difficulty]}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/80">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: playerColor }}
                />
                <span>Vez de {playerName}</span>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              {!submitted ? (
                <>
                  <p className="text-lg text-slate-200 mb-6 leading-relaxed">
                    {question.question}
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm text-slate-400 mb-2">
                        Sua resposta:
                      </label>
                      <Input
                        type="text"
                        value={answer}
                        onChange={(e) => setAnswer(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Digite sua resposta aqui..."
                        className="bg-slate-700/50 border-slate-600/50 text-slate-200 placeholder:text-slate-500 focus:border-amber-500/50"
                        autoFocus
                      />
                    </div>
                    
                    <Button
                      onClick={handleSubmit}
                      disabled={!answer.trim()}
                      className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-semibold"
                    >
                      Confirmar Resposta
                    </Button>
                  </div>
                </>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {/* Result */}
                  <div className={`text-center p-4 rounded-xl mb-4 ${
                    result?.correct 
                      ? 'bg-emerald-500/20 border border-emerald-500/30' 
                      : 'bg-red-500/20 border border-red-500/30'
                  }`}>
                    <div className="text-4xl mb-2">
                      {result?.correct ? '✓' : '✗'}
                    </div>
                    <h3 className={`text-xl font-bold ${
                      result?.correct ? 'text-emerald-400' : 'text-red-400'
                    }`}>
                      {result?.correct 
                        ? (result.score === 100 ? 'Resposta Perfeita!' : 'Resposta Parcialmente Correta!')
                        : 'Resposta Incorreta'
                      }
                    </h3>
                    {result?.correct && result.score < 100 && (
                      <p className="text-sm text-slate-400 mt-1">
                        Pontuação: {result.score}%
                      </p>
                    )}
                  </div>

                  {/* Your answer */}
                  <div className="mb-4">
                    <p className="text-sm text-slate-400 mb-1">Sua resposta:</p>
                    <p className="text-slate-300 bg-slate-700/50 rounded-lg p-3">
                      {answer}
                    </p>
                  </div>

                  {/* Correct answer */}
                  <div className="mb-4">
                    <p className="text-sm text-slate-400 mb-1">Resposta correta:</p>
                    <p className="text-emerald-400 bg-emerald-500/10 rounded-lg p-3 font-medium">
                      {question.correctAnswer}
                    </p>
                  </div>

                  {/* Explanation */}
                  <div className="mb-6">
                    <p className="text-sm text-slate-400 mb-1">Explicação:</p>
                    <p className="text-sm text-slate-300 bg-slate-700/30 rounded-lg p-3 leading-relaxed">
                      {question.explanation}
                    </p>
                  </div>

                  {/* Reward/Penalty info */}
                  <div className={`text-center p-3 rounded-lg mb-4 ${
                    result?.correct 
                      ? 'bg-emerald-500/10 text-emerald-400' 
                      : 'bg-red-500/10 text-red-400'
                  }`}>
                    {result?.correct ? (
                      <p className="text-sm font-medium">
                        +{Math.round(15 * (result.score / 100))} Poder | +{Math.round(10 * (result.score / 100))} Saúde
                      </p>
                    ) : (
                      <p className="text-sm font-medium">
                        -5 Saúde
                      </p>
                    )}
                  </div>

                  <Button
                    onClick={handleClose}
                    className="w-full bg-slate-700 hover:bg-slate-600 text-white"
                  >
                    Continuar
                  </Button>
                </motion.div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
