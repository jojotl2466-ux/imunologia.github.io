'use client';

import { motion } from 'framer-motion';
import type { Player } from '@/lib/game-types';

interface PlayerCardProps {
  player: Player;
  isActive: boolean;
}

export function PlayerCard({ player, isActive }: PlayerCardProps) {
  return (
    <motion.div
      className={`
        relative p-4 rounded-xl border-2 transition-all duration-300
        ${isActive 
          ? 'border-yellow-400 bg-gradient-to-br from-slate-800/90 to-slate-900/90 shadow-lg shadow-yellow-400/20' 
          : 'border-slate-600/50 bg-slate-800/50'
        }
      `}
      animate={isActive ? { scale: [1, 1.02, 1] } : {}}
      transition={{ duration: 1.5, repeat: isActive ? Infinity : 0 }}
    >
      {/* Active indicator */}
      {isActive && (
        <motion.div
          className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <span className="text-xs">▶</span>
        </motion.div>
      )}

      <div className="flex items-center gap-3">
        {/* Player avatar */}
        <div
          className="w-12 h-12 rounded-full border-3 border-white/30 flex items-center justify-center text-xl font-bold text-white shadow-lg"
          style={{ backgroundColor: player.color }}
        >
          {player.type === 'immune_cell' ? '🛡️' : '🦠'}
        </div>

        <div className="flex-1">
          <h3 className="font-bold text-white text-sm">{player.name}</h3>
          <p className="text-xs text-slate-400">
            Casa {player.position + 1}
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-3 space-y-2">
        {/* Health bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Saúde</span>
            <span className="text-emerald-400 font-medium">{player.health}</span>
          </div>
          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${player.health}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Power bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Poder</span>
            <span className="text-blue-400 font-medium">{player.power}</span>
          </div>
          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${player.power}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
