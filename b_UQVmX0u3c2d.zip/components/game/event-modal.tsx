'use client';

import { motion, AnimatePresence } from 'framer-motion';
import type { Tile } from '@/lib/game-types';
import { TILE_CONFIGS } from '@/lib/game-types';
import { Button } from '@/components/ui/button';

interface EventModalProps {
  tile: Tile | null;
  isOpen: boolean;
  onClose: () => void;
}

export function EventModal({ tile, isOpen, onClose }: EventModalProps) {
  if (!tile) return null;

  const config = TILE_CONFIGS[tile.type];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className={`
              relative w-80 p-6 rounded-2xl shadow-2xl
              bg-gradient-to-br ${config.color}
              border-2 border-white/30
            `}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Decorative background */}
            <div className="absolute inset-0 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.2),transparent_50%)]" />
              <motion.div
                className="absolute inset-0"
                animate={{
                  background: [
                    'radial-gradient(circle at 70% 70%, rgba(255,255,255,0.1) 0%, transparent 50%)',
                    'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.1) 0%, transparent 50%)',
                    'radial-gradient(circle at 70% 70%, rgba(255,255,255,0.1) 0%, transparent 50%)',
                  ],
                }}
                transition={{ duration: 4, repeat: Infinity }}
              />
            </div>

            <div className="relative z-10">
              {/* Icon */}
              <motion.div
                className="text-6xl text-center mb-4"
                animate={{ 
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {config.emoji}
              </motion.div>

              {/* Title */}
              <h2 className="text-2xl font-bold text-white text-center mb-2 drop-shadow-lg">
                {tile.label}
              </h2>

              {/* Description */}
              <p className="text-white/90 text-center text-sm mb-6 leading-relaxed">
                {tile.description}
              </p>

              {/* Close button */}
              <Button
                onClick={onClose}
                className="w-full bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm"
              >
                Continuar
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
