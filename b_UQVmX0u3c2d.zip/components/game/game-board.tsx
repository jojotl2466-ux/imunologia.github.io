'use client';

import { motion } from 'framer-motion';
import type { Tile, Player } from '@/lib/game-types';
import { GameTile } from './game-tile';

interface GameBoardProps {
  tiles: Tile[];
  players: Player[];
  highlightedTiles: number[];
  onTileClick: (tile: Tile) => void;
}

export function GameBoard({ tiles, players, highlightedTiles, onTileClick }: GameBoardProps) {
  // Create a 7x7 grid map
  const gridSize = 7;
  const grid: (Tile | null)[][] = Array(gridSize).fill(null).map(() => Array(gridSize).fill(null));
  
  tiles.forEach(tile => {
    if (tile.x >= 0 && tile.x < gridSize && tile.y >= 0 && tile.y < gridSize) {
      grid[tile.y][tile.x] = tile;
    }
  });

  return (
    <motion.div
      className="relative bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 rounded-3xl p-6 shadow-2xl border-2 border-teal-500/30 backdrop-blur-sm"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Board background decoration */}
      <div className="absolute inset-0 rounded-3xl overflow-hidden">
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px',
          }}
        />
        
        {/* Radial glow */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(20,184,166,0.15),transparent_70%)]" />
        
        {/* Corner accents */}
        <div className="absolute top-0 left-0 w-20 h-20 bg-gradient-to-br from-teal-500/20 to-transparent rounded-tl-3xl" />
        <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-blue-500/20 to-transparent rounded-tr-3xl" />
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-emerald-500/20 to-transparent rounded-bl-3xl" />
        <div className="absolute bottom-0 right-0 w-20 h-20 bg-gradient-to-tl from-cyan-500/20 to-transparent rounded-br-3xl" />
      </div>

      {/* Board title */}
      <div className="relative mb-4 text-center">
        <h2 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-400">
          Sistema Imunológico
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">Navegue pelo corpo humano</p>
      </div>

      {/* Game grid */}
      <div className="relative grid grid-cols-7 gap-2">
        {grid.map((row, y) =>
          row.map((tile, x) => (
            <div
              key={`${x}-${y}`}
              className="aspect-square"
            >
              {tile ? (
                <GameTile
                  tile={tile}
                  players={players}
                  isHighlighted={highlightedTiles.includes(tile.id)}
                  onClick={() => onTileClick(tile)}
                />
              ) : (
                // Empty cell with subtle decoration
                <div className="w-full h-full rounded-lg bg-slate-800/30 border border-slate-700/30 flex items-center justify-center">
                  <motion.div
                    className="w-2 h-2 rounded-full bg-slate-700/50"
                    animate={{ opacity: [0.3, 0.5, 0.3] }}
                    transition={{ duration: 2, repeat: Infinity, delay: (x + y) * 0.1 }}
                  />
                </div>
              )}
            </div>
          ))
        )}

        {/* Connection lines between tiles - SVG overlay */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(20, 184, 166, 0.3)" />
              <stop offset="100%" stopColor="rgba(59, 130, 246, 0.3)" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Legend */}
      <div className="relative mt-4 flex flex-wrap justify-center gap-2 text-[10px]">
        {[
          { emoji: '🦠', label: 'Vírus' },
          { emoji: '🛡️', label: 'Defesa' },
          { emoji: '💊', label: 'Remédio' },
          { emoji: '🧬', label: 'Mutação' },
          { emoji: '❤️', label: 'Sangue' },
        ].map(item => (
          <div key={item.label} className="flex items-center gap-1 bg-slate-800/50 px-2 py-0.5 rounded-full">
            <span>{item.emoji}</span>
            <span className="text-slate-400">{item.label}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
