'use client';

import { motion } from 'framer-motion';

function HeartMonitor({ className }: { className?: string }) {
  return (
    <div className={`bg-slate-800/80 rounded-lg p-2 border border-slate-600/50 ${className}`}>
      <div className="flex items-center gap-2 mb-1">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-[10px] text-slate-400">ECG</span>
      </div>
      <svg viewBox="0 0 100 30" className="w-full h-8">
        <motion.path
          d="M0,15 L20,15 L25,5 L30,25 L35,10 L40,15 L100,15"
          fill="none"
          stroke="#10b981"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </svg>
      <div className="flex justify-between text-[9px] text-emerald-400 mt-1">
        <span>72 BPM</span>
        <span>98% SpO2</span>
      </div>
    </div>
  );
}

function TestTubes({ className }: { className?: string }) {
  const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b'];
  
  return (
    <div className={`flex gap-1 ${className}`}>
      {colors.map((color, i) => (
        <div key={i} className="flex flex-col items-center">
          <div className="w-3 h-1 bg-slate-500 rounded-t-sm" />
          <div 
            className="w-2.5 h-8 rounded-b-full border border-slate-500/50 overflow-hidden bg-slate-700/50"
          >
            <motion.div
              className="w-full rounded-b-full"
              style={{ backgroundColor: color }}
              initial={{ height: '40%' }}
              animate={{ height: ['40%', '60%', '40%'] }}
              transition={{ duration: 3, repeat: Infinity, delay: i * 0.5 }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function Microscope({ className }: { className?: string }) {
  return (
    <div className={`text-3xl ${className}`}>
      <motion.div
        animate={{ rotate: [0, 5, -5, 0] }}
        transition={{ duration: 4, repeat: Infinity }}
      >
        🔬
      </motion.div>
    </div>
  );
}

function Syringe({ className }: { className?: string }) {
  return (
    <motion.div 
      className={`text-2xl ${className}`}
      animate={{ x: [0, 3, 0], rotate: [0, 10, 0] }}
      transition={{ duration: 2, repeat: Infinity }}
    >
      💉
    </motion.div>
  );
}

function DNAHelix({ className }: { className?: string }) {
  return (
    <motion.div 
      className={`text-2xl ${className}`}
      animate={{ rotate: 360 }}
      transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
    >
      🧬
    </motion.div>
  );
}

function MedicalBed({ className }: { className?: string }) {
  return (
    <div className={`bg-slate-700/50 rounded-lg p-2 border border-slate-600/30 ${className}`}>
      <div className="w-full h-6 bg-gradient-to-r from-teal-800 to-teal-700 rounded-md border border-teal-600/50">
        <div className="w-full h-2 bg-white/20 rounded-t-md" />
      </div>
      <div className="flex justify-between mt-1">
        <div className="w-2 h-3 bg-slate-500 rounded-sm" />
        <div className="w-2 h-3 bg-slate-500 rounded-sm" />
      </div>
    </div>
  );
}

function LabEquipment({ className }: { className?: string }) {
  return (
    <div className={`flex items-end gap-1 ${className}`}>
      <motion.div 
        className="w-4 h-6 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg border border-blue-300/30"
        animate={{ opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 2, repeat: Infinity }}
      />
      <motion.div 
        className="w-3 h-4 bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-lg border border-emerald-300/30"
        animate={{ opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
      />
      <motion.div 
        className="w-5 h-8 bg-gradient-to-t from-purple-600 to-purple-400 rounded-t-lg border border-purple-300/30"
        animate={{ opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 2, repeat: Infinity, delay: 1 }}
      />
    </div>
  );
}

function Bacteria({ className }: { className?: string }) {
  return (
    <motion.div
      className={`text-xl ${className}`}
      animate={{ 
        scale: [1, 1.2, 1],
        rotate: [0, 180, 360],
      }}
      transition={{ duration: 5, repeat: Infinity }}
    >
      🦠
    </motion.div>
  );
}

function Cell({ className }: { className?: string }) {
  return (
    <motion.div
      className={`w-6 h-6 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 border border-pink-300/50 ${className}`}
      animate={{ 
        scale: [1, 1.1, 0.9, 1],
      }}
      transition={{ duration: 3, repeat: Infinity }}
    >
      <div className="w-2 h-2 bg-rose-700 rounded-full mt-1.5 ml-1.5" />
    </motion.div>
  );
}

export function HospitalDecor() {
  return (
    <>
      {/* Top decorations */}
      <div className="absolute top-4 left-4 flex items-start gap-4">
        <HeartMonitor className="w-28" />
        <TestTubes />
        <Microscope />
      </div>

      <div className="absolute top-4 right-4 flex items-start gap-4">
        <LabEquipment />
        <DNAHelix />
        <Syringe />
      </div>

      {/* Bottom decorations */}
      <div className="absolute bottom-4 left-4 flex items-end gap-4">
        <MedicalBed className="w-24" />
        <Bacteria />
        <Cell />
      </div>

      <div className="absolute bottom-4 right-4 flex items-end gap-4">
        <Cell />
        <TestTubes />
        <Bacteria className="opacity-70" />
      </div>

      {/* Side decorations */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col gap-4">
        <motion.div
          className="text-2xl"
          animate={{ y: [0, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          💊
        </motion.div>
        <motion.div
          className="text-2xl"
          animate={{ y: [0, 5, 0] }}
          transition={{ duration: 2.5, repeat: Infinity }}
        >
          🩺
        </motion.div>
      </div>

      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-4">
        <motion.div
          className="text-2xl"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          ❤️
        </motion.div>
        <motion.div
          className="text-2xl"
          animate={{ rotate: [0, 15, -15, 0] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          🧪
        </motion.div>
      </div>

      {/* Floating particles */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1.5 h-1.5 rounded-full bg-teal-400/30"
          style={{
            left: `${10 + Math.random() * 80}%`,
            top: `${10 + Math.random() * 80}%`,
          }}
          animate={{
            y: [0, -20, 0],
            opacity: [0.3, 0.7, 0.3],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: i * 0.3,
          }}
        />
      ))}
    </>
  );
}
