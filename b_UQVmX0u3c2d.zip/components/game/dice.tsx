'use client';

import { motion, AnimatePresence } from 'framer-motion';

interface DiceProps {
  value: number | null;
  isRolling: boolean;
  onRoll: () => void;
  disabled: boolean;
}

function DiceDot({ className = '' }: { className?: string }) {
  return (
    <div className={`w-3 h-3 bg-slate-900 rounded-full shadow-inner ${className}`} />
  );
}

function DiceFace({ value }: { value: number }) {
  switch (value) {
    case 1:
      return (
        <div className="w-full h-full flex items-center justify-center">
          <DiceDot />
        </div>
      );
    case 2:
      return (
        <div className="w-full h-full p-2 flex flex-col justify-between">
          <div className="flex justify-end">
            <DiceDot />
          </div>
          <div className="flex justify-start">
            <DiceDot />
          </div>
        </div>
      );
    case 3:
      return (
        <div className="w-full h-full p-2 flex flex-col justify-between">
          <div className="flex justify-end">
            <DiceDot />
          </div>
          <div className="flex justify-center">
            <DiceDot />
          </div>
          <div className="flex justify-start">
            <DiceDot />
          </div>
        </div>
      );
    case 4:
      return (
        <div className="w-full h-full p-2 flex flex-col justify-between">
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
        </div>
      );
    case 5:
      return (
        <div className="w-full h-full p-2 flex flex-col justify-between">
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
          <div className="flex justify-center">
            <DiceDot />
          </div>
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
        </div>
      );
    case 6:
      return (
        <div className="w-full h-full p-2 flex flex-col justify-between">
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
          <div className="flex justify-between">
            <DiceDot />
            <DiceDot />
          </div>
        </div>
      );
    default:
      return null;
  }
}

export function Dice({ value, isRolling, onRoll, disabled }: DiceProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <motion.button
        onClick={onRoll}
        disabled={disabled || isRolling}
        className="relative w-16 h-16 bg-white rounded-xl shadow-[inset_0_-4px_0_0_rgba(0,0,0,0.1),0_4px_12px_rgba(0,0,0,0.3)] border border-slate-200 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer overflow-hidden"
        whileHover={!disabled && !isRolling ? { scale: 1.05 } : {}}
        whileTap={!disabled && !isRolling ? { scale: 0.95 } : {}}
        animate={isRolling ? { 
          rotateX: [0, 360, 720, 1080],
          rotateY: [0, 180, 360, 540],
          rotateZ: [0, 45, 0, -45, 0],
        } : {}}
        transition={{ duration: 0.8, ease: "easeOut" }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Dice surface texture */}
        <div className="absolute inset-0 bg-gradient-to-br from-white via-slate-50 to-slate-100 rounded-xl" />
        
        {/* Inner shadow for depth */}
        <div className="absolute inset-0 rounded-xl shadow-[inset_2px_2px_4px_rgba(0,0,0,0.05)]" />
        
        <AnimatePresence mode="wait">
          <motion.div
            key={value || 'empty'}
            initial={{ opacity: 0, scale: 0.5, rotate: -180 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            exit={{ opacity: 0, scale: 0.5, rotate: 180 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-1"
          >
            {value && !isRolling ? (
              <DiceFace value={value} />
            ) : (
              <div className="flex items-center justify-center h-full text-slate-400 font-bold text-xl">
                ?
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </motion.button>
      
      <span className="text-xs text-muted-foreground font-medium text-center">
        {isRolling ? 'Rolando...' : disabled ? 'Aguarde' : 'Clique para rolar'}
      </span>
    </div>
  );
}
