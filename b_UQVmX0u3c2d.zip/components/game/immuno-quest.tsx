'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useGameState } from '@/hooks/use-game-state';
import { GameSetup } from './game-setup';
import { GameBoard } from './game-board';
import { Dice } from './dice';
import { PlayerCard } from './player-card';
import { EventModal } from './event-modal';
import { QuestionModal } from './question-modal';
import { HospitalDecor } from './hospital-decor';
import { Button } from '@/components/ui/button';

interface PlayerSetup {
  name: string;
  icon: string;
}

export function ImmunoQuest() {
  const { 
    tiles, 
    gameState, 
    currentPlayer, 
    currentTile,
    initializePlayers,
    rollDice, 
    answerQuestion,
    endTurn, 
    resetGame,
    goToSetup,
  } = useGameState();

  const handleStartGame = (players: PlayerSetup[]) => {
    initializePlayers(players);
  };

  const highlightedTiles = currentPlayer 
    ? [currentPlayer.position]
    : [];

  // Show setup screen
  if (gameState.gamePhase === 'setup') {
    return <GameSetup onStartGame={handleStartGame} />;
  }

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hospital background decorations */}
      <HospitalDecor />
      
      {/* Main game container */}
      <div className="relative z-10 flex flex-col lg:flex-row items-start justify-center gap-6 p-4 min-h-screen">
        {/* Left panel - Player info */}
        <motion.div
          className="w-full lg:w-72 space-y-3"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          {/* Game title */}
          <div className="text-center lg:text-left mb-4">
            <h1 className="text-2xl lg:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-400">
              ImmunoQuest
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              A batalha pelo sistema imunológico
            </p>
          </div>

          {/* Player cards - scrollable for many players */}
          <div className="space-y-2 max-h-[calc(100vh-400px)] overflow-y-auto pr-1 custom-scrollbar">
            {gameState.players.map((player, index) => (
              <PlayerCard
                key={player.id}
                player={player}
                isActive={index === gameState.currentPlayerIndex}
              />
            ))}
          </div>

          {/* Turn indicator */}
          <div className="bg-slate-800/50 rounded-xl p-3 border border-slate-700/50">
            <p className="text-xs text-slate-400 mb-1">Turno atual</p>
            <p className="text-base font-bold" style={{ color: currentPlayer?.color }}>
              {currentPlayer?.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {gameState.gamePhase === 'waiting' && 'Role o dado para jogar'}
              {gameState.gamePhase === 'rolling' && 'Rolando...'}
              {gameState.gamePhase === 'moving' && 'Movendo...'}
              {gameState.gamePhase === 'event' && 'Evento ativo!'}
              {gameState.gamePhase === 'question' && 'Responda a pergunta!'}
            </p>
          </div>
        </motion.div>

        {/* Center - Game board */}
        <motion.div
          className="flex-shrink-0"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <GameBoard
            tiles={tiles}
            players={gameState.players}
            highlightedTiles={highlightedTiles}
            onTileClick={() => {}}
          />
        </motion.div>

        {/* Right panel - Controls */}
        <motion.div
          className="w-full lg:w-64 space-y-4"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          {/* Dice section */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 flex flex-col items-center">
            <h3 className="text-sm font-semibold text-slate-300 mb-4">Dado</h3>
            <Dice
              value={gameState.diceValue}
              isRolling={gameState.isRolling}
              onRoll={rollDice}
              disabled={gameState.gamePhase !== 'waiting' && gameState.gamePhase !== 'rolling'}
            />
            {gameState.diceValue && !gameState.isRolling && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-2 text-lg font-bold text-teal-400"
              >
                Avança {gameState.diceValue} {gameState.diceValue === 1 ? 'casa' : 'casas'}
              </motion.div>
            )}
          </div>

          {/* Action buttons */}
          <div className="space-y-2">
            {gameState.gamePhase === 'event' && !gameState.winner && (
              <Button
                onClick={endTurn}
                className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white"
              >
                Finalizar Turno
              </Button>
            )}
            
            <Button
              onClick={resetGame}
              variant="outline"
              className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Reiniciar Jogo
            </Button>

            <Button
              onClick={goToSetup}
              variant="ghost"
              className="w-full text-slate-400 hover:text-slate-200 hover:bg-slate-700/50"
            >
              Novo Jogo
            </Button>
          </div>

          {/* Current event display */}
          {gameState.currentEvent && !gameState.winner && gameState.gamePhase !== 'question' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 rounded-xl p-4 border border-teal-500/30"
            >
              <h3 className="text-sm font-semibold text-teal-400 mb-2">Evento</h3>
              <p className="text-sm text-slate-300">{gameState.currentEvent}</p>
            </motion.div>
          )}

          {/* Game info */}
          <div className="bg-slate-800/30 rounded-xl p-4 border border-slate-700/30">
            <h3 className="text-sm font-semibold text-slate-400 mb-3">Como Jogar</h3>
            <ul className="text-xs text-slate-500 space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-teal-400">1.</span>
                <span>Role o dado para avançar</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-teal-400">2.</span>
                <span>Responda perguntas de imunologia</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-teal-400">3.</span>
                <span>Colete anticorpos e remédios</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-teal-400">4.</span>
                <span>Chegue ao final para vencer!</span>
              </li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Event Modal */}
      <EventModal
        tile={currentTile}
        isOpen={gameState.gamePhase === 'event' && currentTile?.type !== 'normal' && currentTile?.type !== 'question' && !gameState.winner}
        onClose={endTurn}
      />

      {/* Question Modal */}
      <QuestionModal
        question={gameState.currentQuestion}
        isOpen={gameState.gamePhase === 'question' && gameState.currentQuestion !== null}
        playerName={currentPlayer?.name || ''}
        playerColor={currentPlayer?.color || '#38bdf8'}
        onAnswer={answerQuestion}
      />

      {/* Winner Modal */}
      <AnimatePresence>
        {gameState.winner && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-8 rounded-3xl shadow-2xl border-2 border-white/30 text-center max-w-md mx-4"
            >
              <motion.div
                className="text-6xl mb-4"
                animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                🏆
              </motion.div>
              <h2 className="text-3xl font-bold text-white mb-2">Vitória!</h2>
              <p className="text-xl text-white/90 mb-6">
                {gameState.winner.name} venceu a batalha!
              </p>
              <p className="text-sm text-white/70 mb-6">
                O sistema imunológico foi fortalecido com sucesso!
              </p>
              <div className="flex flex-col gap-2">
                <Button
                  onClick={resetGame}
                  className="bg-white/20 hover:bg-white/30 text-white border border-white/30 px-8"
                >
                  Jogar Novamente
                </Button>
                <Button
                  onClick={goToSetup}
                  variant="ghost"
                  className="text-white/70 hover:text-white hover:bg-white/10"
                >
                  Novo Jogo
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
