import { redirect } from 'next/navigation'

export default function Home() {
  redirect('/immuno-quest.html')
}
